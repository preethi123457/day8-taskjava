package com.java.day3;
public class Multiplication {
	
		public static void main(String args[]){
		int num1=100,num2=100,product;
		product=num1*num2;
		System.out.println("The product of given two numbers is: "+product);
		}
		}