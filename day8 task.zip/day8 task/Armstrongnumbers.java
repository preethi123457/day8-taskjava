package com.java.day3;

public class Armstrongnumbers {
	public void show(int start, int stop) {
		int i,temp,num,rem,ad;
		ad=0;
		for(i=start;i<=stop;i++)
		{
			temp=i;
			num=0;
			while(temp!=0)
			{
				rem=temp%10;
				num=num+rem*rem*rem;
				temp=temp/10;
			}
			if(i==num)
			{
				System.out.println("the amstrong numbers between" +start+ "and" +stop+ "is" +i);
				ad++;
			}
		}
		if(ad==0) {
			System.out.println("no amstrong numbers between" +start+ "and" +stop);
		}
	}
	
	public static void main(String[] args) {
		int start,stop;
		start=153;
		stop=1000;
		
		Armstrongnumbers obj= new Armstrongnumbers();
		obj.show(start,stop);
		
	}

}
